from variable import *
from dominio import *

def main():
    lista = [1, 8, 6, 5]

    print(len(lista))

if __name__=="__main__":
    main()